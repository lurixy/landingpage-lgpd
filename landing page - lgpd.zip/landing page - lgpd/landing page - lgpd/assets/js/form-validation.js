/*=============== FORM VALIDATION AND ENHANCEMENTS ===============*/

// Form validation utilities
const FormValidator = {
    // Email validation regex
    emailRegex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    
    // Phone validation regex (Brazilian format)
    phoneRegex: /^(\(?\d{2}\)?\s?)?(\d{4,5})-?(\d{4})$/,
    
    // Name validation (min 2 chars, only letters and spaces)
    nameRegex: /^[a-zA-ZÀ-ÿ\s]{2,}$/,

    // Validate individual field
    validateField(field) {
        const value = field.value.trim();
        const fieldType = field.type;
        const fieldName = field.name;
        let isValid = true;
        let errorMessage = '';

        // Check required fields
        if (field.required && !value) {
            isValid = false;
            errorMessage = 'Este campo é obrigatório.';
        }
        // Validate email
        else if (fieldType === 'email' && value && !this.emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Por favor, insira um e-mail válido.';
        }
        // Validate name
        else if (fieldName === 'nome' && value && !this.nameRegex.test(value)) {
            isValid = false;
            errorMessage = 'Nome deve conter apenas letras e ter pelo menos 2 caracteres.';
        }
        // Validate phone (optional but if filled, must be valid)
        else if (fieldType === 'tel' && value && !this.phoneRegex.test(value)) {
            isValid = false;
            errorMessage = 'Por favor, insira um telefone válido. Ex: (11) 99999-9999';
        }

        return { isValid, errorMessage };
    },

    // Show error message
    showError(field, message) {
        const errorElement = document.getElementById(field.getAttribute('aria-describedby'));
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.setAttribute('aria-live', 'polite');
        }
        field.setAttribute('aria-invalid', 'true');
    },

    // Clear error message
    clearError(field) {
        const errorElement = document.getElementById(field.getAttribute('aria-describedby'));
        if (errorElement) {
            errorElement.textContent = '';
        }
        field.setAttribute('aria-invalid', 'false');
    },

    // Validate entire form
    validateForm(form) {
        const fields = form.querySelectorAll('input[required], input[type="email"], input[name="nome"], input[type="tel"]');
        let isFormValid = true;

        fields.forEach(field => {
            const { isValid, errorMessage } = this.validateField(field);
            
            if (!isValid) {
                this.showError(field, errorMessage);
                isFormValid = false;
            } else {
                this.clearError(field);
            }
        });

        return isFormValid;
    }
};

// Initialize form validation when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Add real-time validation to form fields
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const fields = form.querySelectorAll('input');
        
        fields.forEach(field => {
            // Validate on blur (when user leaves the field)
            field.addEventListener('blur', function() {
                const { isValid, errorMessage } = FormValidator.validateField(this);
                
                if (!isValid) {
                    FormValidator.showError(this, errorMessage);
                } else {
                    FormValidator.clearError(this);
                }
            });

            // Clear errors on input (while typing)
            field.addEventListener('input', function() {
                if (this.getAttribute('aria-invalid') === 'true') {
                    const { isValid } = FormValidator.validateField(this);
                    if (isValid) {
                        FormValidator.clearError(this);
                    }
                }
            });
        });

        // Handle form submission
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const isValid = FormValidator.validateForm(this);
            
            if (isValid) {
                // Add loading state
                const submitButton = this.querySelector('button[type="submit"]');
                if (submitButton) {
                    submitButton.classList.add('loading');
                    submitButton.disabled = true;
                }

                // Simulate form submission (replace with actual submission logic)
                setTimeout(() => {
                    alert('Formulário enviado com sucesso! Entraremos em contato em breve.');
                    
                    // Reset form and loading state
                    this.reset();
                    if (submitButton) {
                        submitButton.classList.remove('loading');
                        submitButton.disabled = false;
                    }

                    // Clear all error messages
                    const errorElements = this.querySelectorAll('.error-message');
                    errorElements.forEach(error => error.textContent = '');
                }, 2000);
            } else {
                // Focus on first invalid field
                const firstInvalidField = this.querySelector('[aria-invalid="true"]');
                if (firstInvalidField) {
                    firstInvalidField.focus();
                }
            }
        });
    });

    // Phone number formatting
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            
            if (value.length >= 11) {
                value = value.replace(/^(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
            } else if (value.length >= 7) {
                value = value.replace(/^(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
            } else if (value.length >= 3) {
                value = value.replace(/^(\d{2})(\d{0,5})/, '($1) $2');
            }
            
            this.value = value;
        });
    });

    // Improve keyboard navigation for custom elements
    const customButtons = document.querySelectorAll('.nav__toggle, .nav__close, .change-theme');
    customButtons.forEach(button => {
        button.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });

    // Add smooth scroll behavior with reduced motion respect
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            const target = document.querySelector(href);
            
            if (target) {
                e.preventDefault();
                
                // Check if user prefers reduced motion
                const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                
                target.scrollIntoView({
                    behavior: prefersReducedMotion ? 'auto' : 'smooth',
                    block: 'start'
                });

                // Update focus for accessibility
                target.setAttribute('tabindex', '-1');
                target.focus();
            }
        });
    });

    // Announce page changes for screen readers
    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            document.title = document.title; // Trigger screen reader announcement
        }
    }).observe(document, {subtree: true, childList: true});

    // Add loading states to contact buttons
    const contactButtons = document.querySelectorAll('.contact__card-button');
    contactButtons.forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent;
            this.innerHTML = '<i class="bx bx-loader-alt bx-spin"></i> Carregando...';
            this.disabled = true;

            // Simulate action (replace with actual functionality)
            setTimeout(() => {
                this.textContent = buttonText;
                this.disabled = false;
                
                // Show success message
                const message = document.createElement('div');
                message.className = 'success-message';
                message.textContent = 'Ação realizada com sucesso!';
                message.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: var(--success-color);
                    color: white;
                    padding: 1rem;
                    border-radius: 8px;
                    z-index: 1000;
                    animation: slideIn 0.3s ease;
                `;
                
                document.body.appendChild(message);
                
                setTimeout(() => {
                    message.remove();
                }, 3000);
            }, 1500);
        });
    });
});

// Utility function to show notifications
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.textContent = message;
    notification.setAttribute('role', 'alert');
    notification.setAttribute('aria-live', 'assertive');
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        z-index: 1000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        background: ${type === 'success' ? 'var(--success-color)' : 'var(--danger-color)'};
    `;
    
    document.body.appendChild(notification);
    
    // Trigger animation
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 4 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => notification.remove(), 300);
    }, 4000);
}
